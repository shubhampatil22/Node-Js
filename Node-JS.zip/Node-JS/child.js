const cp = require('child_process')

cp.exec('start chrome https://www.javatpoint.com/nodejs-child-process   ');