const express = require('express');

const app = express();

const jwt = require('jsonwebtoken');

const secretkey = "Shubham@3214"

app.get('/home', (req, res) => {
    res.send('JWT Token Page');
})

// with help of middleware we can verify user
app.get('/login', (req, res) => {
    // res.send('JWT Token Page');
    const user = {
        id : 1,
        username : 'abc',
        password : '123'
    }

    // sign method is used to genrate token and return token as json string
    jwt.sign(user,secretkey, (err , token) => {
        res.json(token);
    })
})

app.post('/profile', verifyToken ,(req, res) => {
    // console.log(JSON.stringify(req.headers['authorization']));
    console.log(req.token);
    // res.json('Profile Page');
    // verify method genrate singurature using JWt token and secrete key and verifies it if token it valid it send back response
    jwt.verify(req.token, secretkey, (err, result) => {
        if(err){
            console.log('errr',err);
        }else{
            console.log('connect succesfully');
            res.json('Profile Page');
        }
    })
})


function verifyToken(req, res, next) {

    const bearerHeader = req.headers["authorization"];
  
    if (typeof bearerHeader !== "undefined") {
  
      const bearerToken = bearerHeader;
  
      req.token = bearerToken;
  
      next();
  
    } else {
  
      res.sendStatus(403);
  
    }
  
}

app.listen(9002, (error) => {
    if(error) console.log('Error Message');
    console.log('New Server is Started');
})

// How JWT Token WOrks

/*

WHen user sign in authetication server verifies user indetify genrate token with help of payload and secreate key
when user try to access protected data by passing token in http authorization header then server genrate signature and
verifies it. it it verified then response send back to user 

*/ 