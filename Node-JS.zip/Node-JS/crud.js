const express = require('express');

const app = express();

// mysql module is used to connect mysql database with node js
const mysql = require('mysql');

const con = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'test'
})

// con object created during database connection has method connect to check whether database in connected or not
con.connect((err) => {
    if(err) throw err;
    console.log('Database Connected');
})


// get all employees
app.get('/employees', (req,res) => {
    // with query method we read and writr to mysql
    con.query('SELECT * FROM student' , (err, result) => {
        if (err) throw err
        res.json(result);
        res.end();
    })
})

// get specific employee
app.get('/employee/:id', (req,res) => {
    // with query method we read and writr to mysql
    con.query('SELECT * FROM student WHERE id = ?' , [req.params.id] , (err, result) => {
        if (err) throw err
        res.json(result);
        res.end();
        console.log('Employee Fetch Succesfully..!!');
    })
})

// insert employee
app.post('/employee/add', (req, res) => {
    let name = req.query.name;
    let age = req.query.age;
    let address = req.query.address;
    con.query('INSERT INTO student(name, age, address) values (?, ?, ?)',[name, age, address] , (err, result) => {
        res.send('Data Inserted Succesfully');
    })
})

// update employee 
app.put('/employee/update/:id', (req, res) => {
    let id = req.params.id;
    con.query('UPDATE student SET  name = ?, age = ?, address = ? WHERE id = ?' , ['kp',45,'ddc',id], (err,result) => {
        if (err) throw err;
        res.send('Update Data');

    })
    
})

// delete specific employee
app.delete('/employee/delete/:id', (req,res) => {
    // res.send('Hello');
    // console.log('sd');
    con.query("DELETE FROM student WHERE id = ?", [req.params.id] , (err,result) => {
        if (err) throw err
        res.json('Deleted Succedfully');
        res.end();
        console.log('Employee Delete Succesfully..!!');
    })
})

app.get('/user/:a', (req, res) => {
    console.log(req.query.a);
    console.log(req.params);
    console.log(req.url);
    res.send('User Page');
    // res.status(202);
    res.end();
})

app.get('*', (req, res) => {
    res.send('404 Page');
    res.status(202);
    res.end();
})


app.listen(7002 , (err) => {
    if(err) console.log(err);
    console.log('Database Connected');
});