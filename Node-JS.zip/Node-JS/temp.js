const express = require('express');

const app = express();

// mysql module is used to connect mysql database with node js
const mysql = require('mysql');

const con = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'test'
})

// con object created during database connection has method connect to check whether database in connected or not
con.connect((err) => {
    if(err) throw err;
    console.log('Database Connected');
})


app.get('/home',(req,res) => {
    res.send('Home Page');
})

app.listen(8000, () => {
    console.log('Server Created')
})