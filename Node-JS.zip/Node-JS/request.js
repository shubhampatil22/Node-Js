const express = require('express');

const bodyParser = require('body-parser');


const app = express();

// we can pass data by three ways to server through request object
// i. url => query string
// ii. url => params
// iii. through body method

// data pass through post request store in body of header so to access that we require body-parser

app.get('/query' , (req, res) => {
    console.log(req.query);
    // res.send(req.query);
    res.json({name : req.query.x});
})

app.get('/param/:name/:age' , (req, res) => {
    console.log(req.params);
    // res.send(req.query);
    let name = req.params.name;
    let age =  req.params.age;
    res.json({name , age});
})


app.listen(6100);