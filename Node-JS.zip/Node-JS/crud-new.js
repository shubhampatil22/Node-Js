const express = require('express');

const app = express();

const mysql = require('mysql');

const con = mysql.createConnection({
    host : 'localhost',
    user: 'root',
    password: '',
    database: 'test'
})

con.connect((error) => {
    if(!error){
        console.log('Database Connect Successfully');
    }else{
        console.log('Not Connected',error);
    }
})

app.get('/data', (req,res) => {
    res.send('User Data');
})

app.get('/student', (req, res) => {
    con.query('SELECT * FROM student', (err, result) => {
        if(err){
            console.log('Error Occur', err);
        }else{
            res.send(result);
            res.end();  
        }
    })
})

app.get('/student/:id', (req, res) => {
    con.query('SELECT * FROM student where id = ?', [req.params.id] , (err, result) => {
        if(err){
            console.log('Error Occur', err);
        }else{
            res.send(result);
            res.end();  
        }
    })
})

app.post('/student/:name/:age/:address', (req, res) => {
    con.query('Insert into student(name,age,address) values(?, ?, ?)', [req.params.name , req.params.age, req.params.address] , (err, result) => {
        if(err){
            console.log('Error Occur', err);
        }else{
            res.send('Data Insert Successfully');
            res.end();  
        }
    })
})

app.get('*', (req,res) => {
    res.send('Error Page');
})





app.listen(5500, (error) => {
    if(!error){
        console.log('Server Started');
        console.log(__dirname);
    }else{
        console.log('Error Occur');
    }
})