// to access web pages of any web application we need web server, 
// web server handle all http requests for web application

// web server is simple program which serve web pages   

// node js provides capabilities to create own web server that handle http request asychronously.

// with http module we create our own server

var http = require('http');

//create a server object:

// createServer method include request and response parameters which are provided by node js

// the request object can be used to get informantion about the url, request header and data
http.createServer(function (req, res) {
  res.write('Hello World12!'); //write a response to the client
  res.end(); //end the response
}).listen(8081 , () => { console.log('message trigger') });

// console.log("All Ok");