let obj = {
    name : 'shubham',
    age: 24
}
console.log('Debug Start');
console.log(obj.name);
obj.name = 'kunal';

console.log(obj.name);

obj.age = obj.age + 20;

console.log(obj.age);

// node --inspect-brk this give instruction that deugger in listen mode