const dev = {
    name : 'shubham',
    age : 24,
    address : 'pune' 
}

module.exports = dev;