const { json } = require('body-parser');
const http = require('http');
const data = require('./data');


http.createServer((req,res) => {
   
    console.log(req.url);
    if (req.url  == '/'){
        res.write("Hello From Home Page");
        res.end();
    }else if (req.url == '/about'){
        res.write("Hello From About Page");
        res.end();
    }else if (req.url == '/contact'){
        res.write("Hello From Contact Page");
        res.end();
    }else if (req.url == '/userdata') {
        res.write(JSON.stringify(data));
        res.end();
    }
    else{
        res.writeHead(404, {"Content-type" : "text/html"});
        /* res.statusCode = 404; */   
        res.write("<h1>404 Page Not Found..!!</h1>");
        res.end();
    }
    
}).listen(8080);

console.log('end');