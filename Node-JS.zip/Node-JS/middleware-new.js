const express = require('express');

const app = express();

app.use((req,res,next) => {
    console.log('First Middleware is Called..!!');
    console.log(req.query);
    if(!req.query.age){
        res.send('Pleae Provide Age');
    }else if (req.query.age < 18){
        res.send("Please provide Age Greate than 18")
    }
    next();
    // next();
})

const middleware = (req,res,next) => {
    console.log('Middleware is Called..!!');
    next();
}


app.get('/home', middleware, (req, res) => {
    res.send({name: 'shubham'});
})

app.get('/about', (req, res) => {
    res.send('About Page');
})

app.listen(6001, (error) => {
    if(error) console.log('Error Message');
    console.log('New Server is Started');
})