const express = require('express');

const app = express();

const middleware = (req,res,next) => {
    console.log('MiddleWare Called');
    console.log(req.query);
    if(!req.query.age){
        res.send('Pleae Provide Age');
    }else if (req.query.age < 18){
        res.send("Please provide Age Greate than 18")
    }
    next();
}

// app.use(middleware);

app.get('/',middleware,(req,res) => {
    res.send("Welcome to Home Page");
    
})

app.get('/about',(req,res) => {
    console.log('about page');
    res.send("Welcome to About Page");
})

// app.get('*',(req,res) => {
//     res.send("Welcome to Error Page");
// })

app.listen(4000);

