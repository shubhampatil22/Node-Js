const mysql = require('mysql');
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();


// create application/json parser
var jsonParser = bodyParser.json();
 
app.use(cors());

// Start by creating a connection to the database.
var con = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "test"

})

app.get('/studentdata', function(req,res){

    con.query("select * from student" , function(err,result){
        if (err) throw res.json(err);
        // js object can not print in console so we need to either convert it into json or iterate over it
        console.log("Result: " + JSON.stringify(result));
        return res.json(result);
        // result.map((item) => console.log(item));
    })

})

app.post('/adddata', jsonParser, function(req,res){
    var name = req.body.fname;
    var address = req.body.add;
    var age = req.body.age;
    // res.json({id: 2, name : 'kp'});

    console.log(name);
    console.log(address);
    console.log(age);
    // console.log(res);
    var sql = `insert into student (name, address, age) values ("${name}", "${address}", "${age}"`;

    con.query(sql,function(err,result){
        if (err) throw res.json(err);

        return res.json(result);
    })
})

app.listen(9000);

console.log('yj');


// con.connect(function(err){
//     if (err) throw err;
//     console.log("Database Connected!");

//     con.query("select * from student" , function(err,result){
//         if (err) throw err;
//         // js object can not print in console so we need to either convert it into json or iterate over it
//         console.log("Result: " + JSON.stringify(result));
//         // result.map((item) => console.log(item));
//     })
// })