const express = require('express');


const app = express();

// it is route function use to get data from server or api

// this all are basic routes
app.get("" , (req, res) => {
    console.log(req.query.address);
    res.send("Hi this is Home Page </br> <a href = '/about'>Go to About Page</a>");
    res.end();
})

app.get("/about" , (req, res) => {
    // res.write("Hi this is About Page");
    res.send("Hi this is About Page </br> <a href = '/'>Go to Home Page</a>");
    res.end();
})

app.listen(5000);