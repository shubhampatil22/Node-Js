const data = [
    {name: 'shubham' , age : 24},
    {name: 'kunal' , age : 22}
]

module.exports = data;