// var fs = require('fs');
// fs.readFile('index.html', 'utf8' ,function(err, data) {
//     console.log(err, data);
// });

// fs.writeFile('index1.txt', "Hello Content" , function(err){
//     if (err) throw err;
//     console.log('end');
// })