const express = require('express');

const bodyParser = require('body-parser');




const app = express();

// console.log(bodyParser.urlencoded());
// parse application/x-www-form-urlencoded
// urlencoded method is used to access form data
app.use(bodyParser.urlencoded({ extended: false }))

app.get("/", (req, res) => {
    res.send("Home Page :)");
})

// get method is use to handle get request
// req and res object are passed by server in callback function
// req object is used to get data from front end
// res object is used to send data from back end (server)
app.get('/about',(req,res) => {

    // send method send text or html data
    // res.send("Welcome to About Page");
    res.json({name : 'shubham'});
})

app.get('/calculate' , (req,res) => {
    // res.send("Welcome to Contact Page")
    res.sendFile(__dirname + "/index.html")
    // console.log(__dirname + "/index.html");
})

// post method is used to handle post request

app.post('/calculate', (req,res) => {
    
    console.log(req.body.v2);
    // console.log(res.body.v1);
    res.send("<h1>thanks for submission</h1>");
})
/* to handle http post request in express js you need to install middleware known as body parser
   body parser extract all body portion of request and put into res.body method
   the body parser module parse the json, buffer, string and url encoded data
*/

app.listen(3000, (req,res) => {
    console.log('Server is Started');
});