// url module splits up web address into readable part i.e convert it into javascript object 
var url = require('url');
var adr = 'http://localhost:8080/default.html?year=2017&month=february';
var q = url.parse(adr, true);

console.log(q);
console.log(q.query.month);