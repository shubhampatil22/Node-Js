import { Component } from '@angular/core';
import { FormGroup, FormControl, Validator, Validators} from '@angular/forms';

@Component({
  selector: 'app-reactiveform',
  templateUrl: './reactiveform.component.html',
  styleUrls: ['./reactiveform.component.css']
})
export class ReactiveformComponent {
  loginForm = new FormGroup({
    name: new FormControl('', [Validators.required, Validators.pattern('[a-zA-Z]+$')]),
    password: new FormControl('', [Validators.required, Validators.minLength(5) , Validators.maxLength(10)])
  })

  LoginUser(){
    console.log('Click',this.loginForm.value);
  }

  get name(){
    return this.loginForm.get('name')
  }

  get password(){
    return this.loginForm.get('password')
  }
}
