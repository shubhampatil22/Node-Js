import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { TodosComponent } from './Components/todos/todos.component';
import { UsersModule } from './users/users.module';
import { DirectivesComponent } from './Components/directives/directives.component';
import { FormsComponent } from './Components/forms/forms.component';
import { ReactiveformComponent } from './reactiveform/reactiveform.component';
import { PipesComponent } from './pipes/pipes.component';
import { RoutingComponent } from './routing/routing.component';
import { LoginComponent } from './users/login/login.component';
import { HooksComponent } from './hooks/hooks.component';

@NgModule({
  declarations: [
    AppComponent,
    TodosComponent,
    DirectivesComponent,
    FormsComponent,
    ReactiveformComponent,
    PipesComponent,
    RoutingComponent,
    HooksComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule, 
    UsersModule

  ],
  providers: [LoginComponent],
  bootstrap: [AppComponent]
})
export class AppModule { }
// Entry Point
// Components are individual part of website

// External Module => include in imports
// BrowerModule used in DOM Manupulations
// AppRoutingModule used to add routing to component
