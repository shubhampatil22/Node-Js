import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})

export class LoggingService {
  importantValue:number = 42;
  constructor() { }
  
  returnImportantValue(){
    return this.importantValue;
  }

}
