import { Component } from '@angular/core';


@Component({
  selector: 'app-todos',
  templateUrl: './todos.component.html',
  styleUrls: ['./todos.component.css']
})
export class TodosComponent {
    // string interpolation
    x:number = 20;
    y:number = 40;
    z: any;
    colls:string = "varname";
    btnclass:string = "btn-class";

     // property binding
    fname = 'Shubham';
    lname = 'Patil'; 

    isDisabled = false;

    visibility = 'inline-block';

    tagcolor = 'red'

    onClick(){
      console.log('Click Event Happer');
    }
    
    input_text = 'Kunal';

    // ------------------------- learning start

    text1 = "string-first";

    text2 = "string-second";

    text_obj = {'a':10, 'b':20};

    arr = [1,2,3,4,5];

    func() {
      return this.text1;
    }

    // -----------------------

    // Angular data binding is used to cummunicate between typescript code and and other component which is shown to user
    // onw way data binding

    disable = false

    // event binding

    handleClick(val:any){
      alert(val);
    }

    handleChange(val:any){
      console.log('click' , val);
    }

    data:any = '';
    // handleInput($event){
    //   console.log('click happen');
    //   data = $event.target.value;
    // }

    color = 'green';





       
}
