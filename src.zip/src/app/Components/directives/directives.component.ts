import { Component } from '@angular/core';

@Component({
  selector: 'app-directives',
  templateUrl: './directives.component.html',
  styleUrls: ['./directives.component.css']
})
export class DirectivesComponent {
  hideshow:boolean = true
  age = 17
  multi = ['class1', 'class2'];
  names = ['shubham', 'kunal', 'neel', 'rahul', 'sumit'];

  col = 'red';

  isDelightful:boolean = true;

  isGlitter:boolean = true;
}
