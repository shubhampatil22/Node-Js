import { Component } from '@angular/core';

@Component({
  selector: 'app-forms',
  templateUrl: './forms.component.html',
  styleUrls: ['./forms.component.css']
})
export class FormsComponent {
  loginUser(item:any){
    console.log('click', item);
  }

  submitHandle(item:any){
    console.log('click button');
  }
}
