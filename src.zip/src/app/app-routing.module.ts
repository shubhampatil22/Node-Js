import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './users/login/login.component';
import { ProfileComponent } from './users/profile/profile.component';
import { RegisterComponent } from './users/register/register.component';
import { RoutingComponent } from './routing/routing.component';

const routes: Routes = [
  {path : 'login' , component : LoginComponent},
  {path : 'profile' , component : ProfileComponent},
  {path : 'register' , component : RegisterComponent},
  // if any route not match this page will be shown to user
  {path : '**' , component : RoutingComponent},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
