import { Component } from '@angular/core';
import { LoggingService } from '../logging.service';

@Component({
  selector: 'app-routing',
  templateUrl: './routing.component.html',
  styleUrls: ['./routing.component.css'],
  // providers: [LoggingService]
})
export class RoutingComponent {
    constructor(private log : LoggingService){
      // console.error('ROuting Template');
      console.log(log.returnImportantValue());
    }
}
